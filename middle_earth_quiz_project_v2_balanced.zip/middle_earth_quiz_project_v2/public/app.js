const $=id=>document.getElementById(id);
let quiz=null,index=0,answers=[];
const fa=n=>String(n).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[d]);
$("start").onclick=async()=>{
 $("start").disabled=true;
 try{
  const r=await fetch("/api/quiz");if(!r.ok)throw new Error("server");
  quiz=await r.json();index=0;answers=[];
  $("welcome").classList.add("hidden");$("quiz").classList.remove("hidden");render();
 }catch(e){
  alert("برای اجرای آزمون باید سایت از طریق سرور اجرا شود؛ فایل index.html را مستقیم باز نکن. راه‌اندازی در README نوشته شده است.");
  $("start").disabled=false;
 }
};
function render(){
 const q=quiz.questions[index];
 $("progressText").textContent=`پرسش ${fa(index+1)} از ۵`;
 $("questionNumber").textContent=fa(index+1).padStart(2,"۰");
 $("progressBar").style.width=`${(index+1)*20}%`;
 $("question").textContent=q.text;$("options").innerHTML="";
 $("next").disabled=true;$("next").innerHTML=index===4?"ثبت پاسخ‌ها <b>←</b>":"ادامه <b>←</b>";
 q.options.forEach(o=>{
  const b=document.createElement("button");b.type="button";b.className="option";b.textContent=o.text;
  b.onclick=()=>{answers[index]={id:q.id,option:o.index};document.querySelectorAll(".option").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");$("next").disabled=false;};
  $("options").appendChild(b);
 });
}
$("next").onclick=async()=>{
 if(index<4){index++;render();return;}
 $("next").disabled=true;
 try{
  const r=await fetch("/api/submit",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({token:quiz.token,answers})});
  const data=await r.json();if(!r.ok)throw new Error(data.error||"ارسال پاسخ‌ها ناموفق بود.");
  $("quiz").classList.add("hidden");$("result").classList.remove("hidden");
  const heirs=data.faction==="وارثان";
  $("faction").textContent=data.faction;
  $("resultSymbol").textContent=heirs?"✧":"⚔";
  $("resultText").textContent=data.message;
 }catch(e){alert(e.message);$("next").disabled=false;}
};