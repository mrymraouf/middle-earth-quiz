import "dotenv/config";
import express from "express";
import session from "express-session";
import helmet from "helmet";
import Database from "better-sqlite3";
import crypto from "node:crypto";
import fs from "node:fs";

const app = express();
const db = new Database(process.env.DB_PATH || "./data.sqlite");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS participants (
 id TEXT PRIMARY KEY, created_at TEXT NOT NULL, faction TEXT NOT NULL,
 h_score INTEGER NOT NULL, u_score INTEGER NOT NULL, question_ids TEXT NOT NULL
);
`);
const questions = JSON.parse(fs.readFileSync(new URL("./questions.json", import.meta.url)));
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;
if (!ADMIN_PASSWORD || !SESSION_SECRET) {
  console.error("Set ADMIN_PASSWORD and SESSION_SECRET environment variables.");
  process.exit(1);
}
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"20kb"}));
app.use(session({
 secret: SESSION_SECRET, resave:false, saveUninitialized:false,
 cookie:{httpOnly:true,sameSite:"strict",secure:process.env.NODE_ENV==="production",maxAge:8*60*60*1000}
}));
app.use(express.static("public"));

const shuffle = a => [...a].sort(() => Math.random() - 0.5);
const admin = (req,res,next) => req.session?.admin ? next() : res.status(401).json({error:"unauthorized"});

app.get("/api/quiz", (req,res) => {
 const selected = shuffle(questions).slice(0,5).map(q => ({id:q.id,text:q.text,options:q.options.map((o,index)=>({index,text:o.text}))}));
 const token = crypto.randomUUID();
 req.session.quiz = {...req.session.quiz, [token]: selected.map(q=>q.id)};
 res.json({token,questions:selected});
});

app.post("/api/submit", (req,res) => {
 const {token, answers} = req.body || {};
 const ids = req.session.quiz?.[token];
 if (!ids || !Array.isArray(answers) || answers.length !== 5) return res.status(400).json({error:"آزمون معتبر نیست یا قبلاً ارسال شده است."});
 const answerMap = new Map(answers.map(a=>[Number(a.id),Number(a.option)]));
 if (ids.some(id=>!Number.isInteger(answerMap.get(id)) || answerMap.get(id)<0 || answerMap.get(id)>3)) return res.status(400).json({error:"لطفاً به همه سؤال‌ها پاسخ بده."});
 let h=0,u=0;
 for (const id of ids) {
   const q=questions.find(x=>x.id===id), option=q.options[answerMap.get(id)];
   h+=option.h; u+=option.u;
 }
 const id=crypto.randomUUID();
 const created=new Date().toISOString();
 // One SQLite write transaction: concurrent submissions cannot break the <=1 balance rule.
 const assign = db.transaction(() => {
   const counts=db.prepare("SELECT faction, COUNT(*) AS n FROM participants GROUP BY faction").all();
   const hc=counts.find(x=>x.faction==="وارثان")?.n || 0;
   const uc=counts.find(x=>x.faction==="اوروک‌ها")?.n || 0;
   // ابتدا گرایش احتمالی فرد را بر اساس امتیاز وارثان (۰ تا ۱۰) تعیین می‌کنیم.
   // سپس قاعده توازن، در صورت نیاز، نتیجه قرعه را به جبهه کم‌تعدادتر تغییر می‌دهد.
   let preferredFaction;
   if (h >= 9) {
     preferredFaction = "وارثان"; // گرایش قطعی؛ فقط توازن می‌تواند آن را تغییر دهد.
   } else if (h >= 6) {
     preferredFaction = Math.random() < 0.70 ? "وارثان" : "اوروک‌ها";
   } else if (h === 5) {
     preferredFaction = Math.random() < 0.50 ? "وارثان" : "اوروک‌ها";
   } else {
     // امتیازهای ۰ تا ۴: احتمال ۷۰٪ اورک و ۳۰٪ وارث.
     preferredFaction = Math.random() < 0.30 ? "وارثان" : "اوروک‌ها";
   }

   let faction;
   // توازن بر احتمال مقدم است. اگر تعداد برابر باشد، قرعه/گرایش فرد اعمال می‌شود.
   // اگر یک جبهه یک نفر جلو باشد، نفر بعدی الزاماً به جبهه کم‌تعدادتر می‌رود.
   // بنابراین اختلاف همواره حداکثر یک است و در تعداد نهایی زوج، دو جبهه دقیقاً برابرند.
   if (hc > uc) faction = "اوروک‌ها";
   else if (uc > hc) faction = "وارثان";
   else faction = preferredFaction;
   db.prepare("INSERT INTO participants VALUES(?,?,?,?,?,?)").run(id,created,faction,h,u,JSON.stringify(ids));
   return faction;
 });
 const faction=assign();
 delete req.session.quiz[token];
 res.json({faction, message:faction==="وارثان"?"راهت به سوی میراث و اتحاد گشوده شد.":"قدرت و اراده‌ات تو را به صف اوروک‌ها فراخوانده است."});
});

app.post("/api/admin/login",(req,res)=>{
 if(req.body?.password !== ADMIN_PASSWORD) return res.status(401).json({error:"رمز عبور نادرست است."});
 req.session.admin=true; res.json({ok:true});
});
app.post("/api/admin/logout",admin,(req,res)=>{req.session.destroy(()=>res.json({ok:true}));});
app.get("/api/admin/results",admin,(req,res)=>{
 const rows=db.prepare("SELECT id,created_at,faction,h_score,u_score FROM participants ORDER BY created_at DESC").all();
 const heirs=rows.filter(x=>x.faction==="وارثان").length, uruks=rows.length-heirs;
 res.json({total:rows.length,heirs,uruks,rows});
});
app.get("/api/admin/export",admin,(req,res)=>{
 const rows=db.prepare("SELECT id,created_at,faction,h_score,u_score FROM participants ORDER BY created_at").all();
 const csv=["شناسه,زمان ثبت,جبهه,امتیاز وارثان,امتیاز اوروک‌ها",...rows.map(r=>[r.id,r.created_at,r.faction,r.h_score,r.u_score].join(","))].join("\n");
 res.setHeader("Content-Type","text/csv; charset=utf-8");
 res.setHeader("Content-Disposition",'attachment; filename="middle-earth-results.csv"');
 res.send("\uFEFF"+csv);
});
const port=process.env.PORT || 3000;
app.listen(port,()=>console.log(`Quiz running on port ${port}`));
